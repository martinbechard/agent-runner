"use client"

import { useMemo, useRef, useState } from "react"
import {
  RESOLUTIONS,
  formatValue,
  getHeatGroups,
  minuteLabel,
  periodCount,
  rowStats,
  type HeatCell,
  type HeatRow,
  type Resolution,
} from "@/lib/heatmap-data"
import { HeatLegend } from "./heat-legend"
import { CellReadout } from "./cell-readout"
import { EvidencePanel } from "./evidence-panel"

interface CellRef {
  row: HeatRow
  cell: HeatCell
  period: number
}

const HATCH = {
  backgroundImage:
    "repeating-linear-gradient(-45deg, transparent, transparent 3px, var(--grid-line) 3px, var(--grid-line) 4px)",
}

const LABEL_W = 208 // px, sticky metric column
const CELL_W = 52 // px, wide enough for a compact value
const CELL_GAP = 1

function heatBackground(t: number): string {
  return `color-mix(in oklch, var(--heat-high) ${Math.round(t * 100)}%, var(--heat-low))`
}

export function HeatmapBoard() {
  const [resolution, setResolution] = useState<Resolution>(5)
  const [hovered, setHovered] = useState<CellRef | null>(null)
  const [pinned, setPinned] = useState<CellRef | null>(null)
  const [showValues, setShowValues] = useState(true)
  const [groupFilter, setGroupFilter] = useState<string>("all")
  const scrollRef = useRef<HTMLDivElement>(null)

  const allGroups = useMemo(() => getHeatGroups(resolution), [resolution])
  const groups = useMemo(
    () => (groupFilter === "all" ? allGroups : allGroups.filter((g) => g.id === groupFilter)),
    [allGroups, groupFilter],
  )
  const periods = periodCount(resolution)

  const active = hovered ?? pinned
  const activeCol = active?.period ?? -1

  // Label every N columns so ticks stay legible at fine resolutions.
  const labelEveryMin = resolution <= 5 ? 15 : resolution
  const majorTick = (i: number) => (i * resolution) % labelEveryMin === 0

  function changeResolution(r: Resolution) {
    // Keep the viewport anchored on the same wall-clock time when re-bucketing.
    const el = scrollRef.current
    const anchorMin = el ? ((el.scrollLeft / (CELL_W + CELL_GAP)) * resolution) : 0
    setResolution(r)
    setPinned(null)
    setHovered(null)
    requestAnimationFrame(() => {
      if (el) el.scrollLeft = (anchorMin / r) * (CELL_W + CELL_GAP)
    })
  }

  return (
    <section aria-label="Activity heatmap" className="flex flex-col gap-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div
            role="tablist"
            aria-label="Row groups"
            className="flex items-center gap-1 rounded-md border border-border bg-card p-0.5"
          >
            {[{ id: "all", label: "All" }, ...allGroups.map((g) => ({ id: g.id, label: g.label }))].map((g) => (
              <button
                key={g.id}
                role="tab"
                aria-selected={groupFilter === g.id}
                onClick={() => setGroupFilter(g.id)}
                className={`rounded-sm px-2.5 py-1 text-xs font-medium transition-colors ${
                  groupFilter === g.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>

          <div
            role="radiogroup"
            aria-label="Resolution"
            className="flex items-center gap-1 rounded-md border border-border bg-card p-0.5"
          >
            {RESOLUTIONS.map((r) => (
              <button
                key={r}
                role="radio"
                aria-checked={resolution === r}
                onClick={() => changeResolution(r)}
                className={`rounded-sm px-2 py-1 font-mono text-xs transition-colors ${
                  resolution === r
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {r}m
              </button>
            ))}
          </div>

          <span className="font-mono text-[11px] text-muted-foreground">
            {periods} cols · 08:00–12:00
          </span>
        </div>

        <div className="flex items-center gap-4">
          <HeatLegend />
          <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
            <input
              type="checkbox"
              checked={showValues}
              onChange={(e) => setShowValues(e.target.checked)}
              className="size-3.5 accent-[var(--heat-high)]"
            />
            Values
          </label>
        </div>
      </div>

      {/* Hover / pinned readout bar */}
      <CellReadout active={active} resolution={resolution} isPinned={!hovered && !!pinned} onClear={() => setPinned(null)} />

      {/* Scrollable grid with sticky metric column */}
      <div
        ref={scrollRef}
        className="overflow-x-auto rounded-lg border border-border bg-card"
        onMouseLeave={() => setHovered(null)}
      >
        <div className="w-max min-w-full py-3 pr-3">
          {/* Time axis */}
          <div className="flex items-end pb-1.5">
            {/* Corner cell: intentionally blank — acts as an opaque sticky mask so the
                time axis doesn't slide under the row labels during horizontal scroll */}
            <div
              className="sticky left-0 z-20 shrink-0 self-stretch bg-card"
              style={{ width: LABEL_W }}
              aria-hidden="true"
            />
            {Array.from({ length: periods }, (_, i) => (
              <div
                key={i}
                className={`flex shrink-0 flex-col items-center gap-0.5 font-mono text-[10px] ${
                  i === activeCol ? "text-foreground" : "text-muted-foreground"
                }`}
                style={{ width: CELL_W, marginRight: CELL_GAP }}
              >
                {majorTick(i) ? <span>{minuteLabel(i * resolution)}</span> : null}
                <span
                  className={`w-px ${i === activeCol ? "bg-foreground" : "bg-border"} ${
                    majorTick(i) ? "h-2.5" : "h-1.5"
                  }`}
                  aria-hidden="true"
                />
              </div>
            ))}
          </div>

          {groups.map((group) => (
            <div key={group.id} className="mt-1">
              <div className="flex items-end">
                <div
                  className="sticky left-0 z-20 shrink-0 bg-card pb-1 pl-3 pt-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground"
                  style={{ width: LABEL_W }}
                >
                  {group.label}
                </div>
                <div className="mb-0.5 grow border-b border-border/60" />
              </div>

              {group.rows.map((row) => {
                const stats = rowStats(row)
                return (
                  <div key={row.id} className="flex items-center py-px">
                    <div
                      className="sticky left-0 z-20 flex shrink-0 items-baseline justify-between gap-2 self-stretch bg-card pl-3 pr-3"
                      style={{ width: LABEL_W }}
                    >
                      <span className="truncate text-xs text-foreground">{row.label}</span>
                      {stats.flat ? (
                        <span className="shrink-0 rounded-sm border border-border px-1 font-mono text-[9px] uppercase text-muted-foreground">
                          flat {formatValue(stats.max, row.unit)}
                        </span>
                      ) : (
                        <span className="shrink-0 font-mono text-[10px] text-muted-foreground">
                          {formatValue(stats.min, row.unit)}–{formatValue(stats.max, row.unit)}
                        </span>
                      )}
                    </div>

                    {row.cells.map((c, i) => {
                      const isActive = active?.row.id === row.id && active.period === i
                      const isPinnedCell = pinned?.row.id === row.id && pinned.period === i

                      let style: React.CSSProperties
                      let t = 0
                      if (c.status === "unavailable" || c.value === null) {
                        style = { ...HATCH, backgroundColor: "transparent" }
                      } else if (stats.flat) {
                        style = { backgroundColor: "var(--heat-flat)" }
                      } else {
                        t = stats.max === stats.min ? 0 : (c.value - stats.min) / (stats.max - stats.min)
                        style = { backgroundColor: heatBackground(t) }
                      }

                      return (
                        <button
                          key={i}
                          type="button"
                          aria-label={`${row.label}, ${minuteLabel(i * resolution)}: ${
                            c.status === "unavailable" ? "unavailable" : formatValue(c.value, row.unit)
                          }${c.status === "partial" ? " (partial evidence)" : ""}`}
                          onMouseEnter={() => setHovered({ row, cell: c, period: i })}
                          onFocus={() => setHovered({ row, cell: c, period: i })}
                          onClick={() => setPinned(isPinnedCell ? null : { row, cell: c, period: i })}
                          className={`relative h-7 shrink-0 overflow-hidden rounded-[2px] outline-offset-1 transition-[box-shadow] ${
                            isPinnedCell ? "ring-2 ring-ring" : isActive ? "ring-1 ring-foreground/60" : ""
                          }`}
                          style={{ ...style, width: CELL_W, marginRight: CELL_GAP }}
                        >
                          {c.status === "partial" && (
                            <span
                              aria-hidden="true"
                              className="absolute right-0 top-0 size-0 border-l-[7px] border-t-[7px] border-l-transparent"
                              style={{ borderTopColor: "var(--flag)" }}
                            />
                          )}
                          {showValues && c.status !== "unavailable" && !stats.flat && (
                            <span
                              className="pointer-events-none absolute inset-0 flex items-center justify-center font-mono text-[9px] leading-none"
                              style={{ color: t > 0.4 ? "var(--heat-value-dark)" : "var(--muted-foreground)" }}
                            >
                              {formatValue(c.value, row.unit)}
                            </span>
                          )}
                        </button>
                      )
                    })}
                  </div>
                )
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Evidence panel — raw measurements backing the pinned cell */}
      {pinned && (
        <EvidencePanel
          row={pinned.row}
          cell={pinned.cell}
          period={pinned.period}
          resolution={resolution}
          onClose={() => setPinned(null)}
        />
      )}

      <p className="text-xs leading-relaxed text-muted-foreground">
        Intensity is normalized per row — each row label shows its own min–max range at the current resolution.
        Coarser resolutions aggregate 1-minute buckets (sum for time/tokens/cost, average or max for context).
        Click any cell to see the raw evidence behind its number.
      </p>
    </section>
  )
}
