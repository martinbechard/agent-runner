"use client"

import { useMemo, useState } from "react"
import {
  aggLabel,
  formatValue,
  getEvidence,
  getMissingWindows,
  minuteLabel,
  periodRangeLabel,
  unitLabel,
  type HeatCell,
  type HeatRow,
  type Resolution,
} from "@/lib/heatmap-data"

interface EvidencePanelProps {
  row: HeatRow
  cell: HeatCell
  period: number
  resolution: Resolution
  onClose: () => void
}

const VISIBLE_LIMIT = 8

export function EvidencePanel({ row, cell, period, resolution, onClose }: EvidencePanelProps) {
  const [expanded, setExpanded] = useState(false)

  const records = useMemo(() => getEvidence(row.id, resolution, period), [row.id, resolution, period])
  const missing = useMemo(() => getMissingWindows(row.id, resolution, period), [row.id, resolution, period])

  const measured = records.filter((r) => r.kind === "measured")
  const derived = records.filter((r) => r.kind !== "measured")
  const visible = expanded ? records : records.slice(0, VISIBLE_LIMIT)

  return (
    <section
      aria-label={`Evidence for ${row.label}, ${periodRangeLabel(period, resolution)}`}
      className="rounded-lg border border-border bg-card"
    >
      {/* Header */}
      <header className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-b border-border px-4 py-3">
        <h3 className="text-sm font-semibold text-foreground">{row.label}</h3>
        <span className="font-mono text-xs text-muted-foreground">{periodRangeLabel(period, resolution)}</span>
        <span className="font-mono text-sm text-foreground">
          {cell.status === "unavailable" ? "unavailable" : formatValue(cell.value, row.unit)}
          <span className="ml-1 text-xs text-muted-foreground">{unitLabel(row.unit)}</span>
        </span>
        <span className="text-xs text-muted-foreground">{aggLabel(row.agg, cell.bucketMinutes, resolution)}</span>
        <button
          type="button"
          onClick={onClose}
          className="ml-auto rounded-sm border border-border px-2 py-0.5 text-[11px] text-muted-foreground hover:text-foreground"
        >
          Close
        </button>
      </header>

      {/* Coverage summary */}
      <div className="flex flex-wrap items-center gap-x-5 gap-y-1.5 border-b border-border px-4 py-2.5 text-xs">
        <span className="text-muted-foreground">
          Coverage:{" "}
          <span className="font-mono text-foreground">
            {cell.coveredMinutes}/{cell.bucketMinutes} min
          </span>
        </span>
        <span className="text-muted-foreground">
          Raw records: <span className="font-mono text-foreground">{records.length}</span>
        </span>
        <span className="text-muted-foreground">
          Measured: <span className="font-mono text-foreground">{measured.length}</span>
        </span>
        {derived.length > 0 && (
          <span
            className="rounded-sm px-1.5 py-0.5 font-medium"
            style={{
              backgroundColor: "color-mix(in oklch, var(--flag) 18%, transparent)",
              color: "var(--flag)",
            }}
          >
            {derived.length} derived / interpolated
          </span>
        )}
        {missing.map(([a, b]) => (
          <span key={a} className="font-mono text-muted-foreground">
            no data {minuteLabel(a)}–{minuteLabel(b)}
          </span>
        ))}
      </div>

      {/* Evidence table */}
      {records.length === 0 ? (
        <p className="px-4 py-4 text-xs text-muted-foreground">
          No raw measurements exist for this bucket. The collector was offline or the source did not report.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-border/60 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                <th scope="col" className="px-4 py-2 font-medium">Window</th>
                <th scope="col" className="px-4 py-2 font-medium">Source</th>
                <th scope="col" className="px-4 py-2 text-right font-medium">Raw value</th>
                <th scope="col" className="px-4 py-2 font-medium">Quality</th>
                <th scope="col" className="px-4 py-2 font-medium">Note</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((r) => (
                <tr key={r.id} className="border-b border-border/40 last:border-b-0">
                  <td className="whitespace-nowrap px-4 py-1.5 font-mono text-muted-foreground">
                    {minuteLabel(r.startMin)}–{minuteLabel(r.endMin)}
                  </td>
                  <td className="whitespace-nowrap px-4 py-1.5 text-foreground">{r.source}</td>
                  <td className="whitespace-nowrap px-4 py-1.5 text-right font-mono text-foreground">
                    {formatValue(r.value, row.unit)}
                  </td>
                  <td className="whitespace-nowrap px-4 py-1.5">
                    {r.kind === "measured" ? (
                      <span className="text-muted-foreground">measured</span>
                    ) : (
                      <span style={{ color: "var(--flag)" }}>derived</span>
                    )}
                  </td>
                  <td className="max-w-[320px] truncate px-4 py-1.5 text-muted-foreground">{r.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {records.length > VISIBLE_LIMIT && (
            <div className="border-t border-border/40 px-4 py-2">
              <button
                type="button"
                onClick={() => setExpanded((v) => !v)}
                className="text-xs font-medium text-foreground underline-offset-2 hover:underline"
              >
                {expanded ? "Show fewer" : `Show all ${records.length} records`}
              </button>
            </div>
          )}
        </div>
      )}
    </section>
  )
}
