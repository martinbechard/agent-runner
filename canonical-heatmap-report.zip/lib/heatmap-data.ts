export type CellStatus = "measured" | "partial" | "unavailable"

export type RowUnit = "seconds" | "tokens" | "percent" | "usd"

export type AggMethod = "sum" | "avg" | "max"

export interface EvidenceRecord {
  id: string
  source: string
  kind: "measured" | "partial" | "derived"
  startMin: number // minutes from session start
  endMin: number
  value: number
  note: string
}

export interface HeatCell {
  value: number | null
  status: CellStatus
  evidenceCount: number
  /** minutes covered by evidence vs. minutes in the bucket */
  coveredMinutes: number
  bucketMinutes: number
}

export interface HeatRow {
  id: string
  label: string
  unit: RowUnit
  agg: AggMethod
  group: string
  cells: HeatCell[]
}

export interface HeatGroup {
  id: string
  label: string
  rows: HeatRow[]
}

export const TOTAL_MINUTES = 240 // 4 hours: 08:00 – 12:00
export const START_HOUR = 8
export const RESOLUTIONS = [1, 5, 15, 30, 60] as const
export type Resolution = (typeof RESOLUTIONS)[number]

export function minuteLabel(minuteOffset: number): string {
  const h = START_HOUR + Math.floor(minuteOffset / 60)
  const m = minuteOffset % 60
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`
}

export function periodRangeLabel(period: number, resolution: Resolution): string {
  const start = period * resolution
  if (resolution === 1) return minuteLabel(start)
  return `${minuteLabel(start)}–${minuteLabel(Math.min(start + resolution, TOTAL_MINUTES))}`
}

export function formatValue(value: number | null, unit: RowUnit): string {
  if (value === null) return "—"
  switch (unit) {
    case "seconds": {
      if (value === 0) return "0s"
      if (value < 60) return `${Math.round(value)}s`
      const m = Math.floor(value / 60)
      const s = Math.round(value % 60)
      if (m >= 60) {
        const h = Math.floor(m / 60)
        return `${h}h ${m % 60}m`
      }
      return s > 0 ? `${m}m ${s}s` : `${m}m`
    }
    case "tokens": {
      if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`
      if (value >= 10_000) return `${Math.round(value / 1_000)}K`
      if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`
      return String(Math.round(value))
    }
    case "percent":
      return `${Math.round(value)}%`
    case "usd":
      return value < 0.01 && value > 0 ? `$${value.toFixed(4)}` : `$${value.toFixed(2)}`
  }
}

export function unitLabel(unit: RowUnit): string {
  switch (unit) {
    case "seconds":
      return "wall time"
    case "tokens":
      return "tokens"
    case "percent":
      return "of window"
    case "usd":
      return "cost"
  }
}

export function aggLabel(agg: AggMethod, n: number, resolution: Resolution): string {
  if (resolution === 1) return "raw 1-min bucket"
  const m: Record<AggMethod, string> = { sum: "sum", avg: "average", max: "max" }
  return `${m[agg]} of ${n} × 1-min buckets`
}

// ---------------------------------------------------------------------------
// Deterministic base data: 240 one-minute buckets per metric.
// ---------------------------------------------------------------------------

// Seeded PRNG so SSR and client always agree.
function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** Activity envelope over the 4-hour session: three bursts with idle troughs. */
function envelope(t: number): number {
  const bursts: Array<[number, number, number]> = [
    // [center, width, height]
    [18, 16, 1.0],
    [85, 20, 0.85],
    [172, 30, 0.95],
    [225, 12, 0.6],
  ]
  let e = 0.03
  for (const [c, w, h] of bursts) {
    e += h * Math.exp(-((t - c) ** 2) / (2 * (w / 2) ** 2))
  }
  return Math.min(1, e)
}

interface BaseMinute {
  value: number
  status: CellStatus
  evidence: EvidenceRecord[]
}

interface BaseRowDef {
  id: string
  label: string
  unit: RowUnit
  agg: AggMethod
  group: string
  minutes: BaseMinute[]
}

function evidenceFor(
  rowId: string,
  minute: number,
  value: number,
  status: CellStatus,
  rand: () => number,
): EvidenceRecord[] {
  if (status === "unavailable") return []
  const sourceByRow: Record<string, [string, string]> = {
    inference: ["otel: gen_ai.inference spans", "Span durations summed within the bucket"],
    tools: ["otel: tool.execute spans", "Span durations summed within the bucket"],
    wait: ["derived: gaps between spans", "Bucket length minus attributed activity"],
    uncached: ["provider usage API", "usage.prompt_tokens minus cached_tokens"],
    cached: ["provider usage API", "usage.cached_tokens per response"],
    reasoning: ["provider usage API", "usage.reasoning_tokens per response"],
    output: ["provider usage API", "usage.completion_tokens per response"],
    "ctx-avg": ["sampled gauge: context_used_pct", "Mean of per-request samples in bucket"],
    "ctx-max": ["sampled gauge: context_used_pct", "Max of per-request samples in bucket"],
    cost: ["billing export (hourly)", "Provider line items apportioned to bucket"],
  }
  const [source, note] = sourceByRow[rowId] ?? ["unknown", ""]
  const n = value === 0 ? 1 : 1 + Math.floor(rand() * 2) // 1–2 raw records per minute
  const records: EvidenceRecord[] = []
  let remaining = value
  for (let k = 0; k < n; k++) {
    const isLast = k === n - 1
    const slice = isLast ? remaining : Math.round(remaining * (0.35 + rand() * 0.4) * 100) / 100
    remaining = Math.round((remaining - slice) * 100) / 100
    records.push({
      id: `${rowId}-${minute}-${k}`,
      source: status === "partial" && isLast ? "derived: interpolated" : source,
      kind: status === "partial" && isLast ? "derived" : "measured",
      startMin: minute,
      endMin: minute + 1,
      value: slice,
      note: status === "partial" && isLast ? "Gap filled from neighboring buckets" : note,
    })
  }
  return records
}

function buildBaseRow(
  id: string,
  label: string,
  unit: RowUnit,
  agg: AggMethod,
  group: string,
  valueAt: (t: number, rand: () => number) => number,
  statusAt?: (t: number, rand: () => number) => CellStatus,
): BaseRowDef {
  const rand = mulberry32(id.split("").reduce((a, c) => a + c.charCodeAt(0), 7))
  const minutes: BaseMinute[] = []
  for (let t = 0; t < TOTAL_MINUTES; t++) {
    const status = statusAt ? statusAt(t, rand) : "measured"
    const value = status === "unavailable" ? 0 : Math.max(0, valueAt(t, rand))
    minutes.push({ value, status, evidence: evidenceFor(id, t, value, status, rand) })
  }
  return { id, label, unit, agg, group, minutes }
}

const BASE_ROWS: BaseRowDef[] = [
  buildBaseRow(
    "inference",
    "Model inference",
    "seconds",
    "sum",
    "time",
    (t, r) => Math.round(envelope(t) * (34 + r() * 18)),
    (t, r) => (r() < 0.04 && envelope(t) > 0.3 ? "partial" : "measured"),
  ),
  buildBaseRow(
    "tools",
    "Tool execution",
    "seconds",
    "sum",
    "time",
    (t, r) => Math.round(envelope(t) * (10 + r() * 14)),
    (t) => (t >= 118 && t < 126 ? "unavailable" : "measured"),
  ),
  buildBaseRow("wait", "Waiting / idle", "seconds", "sum", "time", (t, r) =>
    Math.round((1 - envelope(t)) * (40 + r() * 20)),
  ),
  buildBaseRow("uncached", "Uncached input", "tokens", "sum", "tokens", (t, r) =>
    Math.round(envelope(t) * (2200 + r() * 1400)),
  ),
  buildBaseRow("cached", "Cached input", "tokens", "sum", "tokens", (t) =>
    envelope(t) > 0.1 ? 240_000 : 0,
  ),
  buildBaseRow(
    "reasoning",
    "Reasoning",
    "tokens",
    "sum",
    "tokens",
    (t, r) => Math.round(envelope(t) * (1500 + r() * 900)),
    (t, r) => (r() < 0.03 ? "partial" : "measured"),
  ),
  buildBaseRow("output", "Output", "tokens", "sum", "tokens", (t, r) =>
    Math.round(envelope(t) * (420 + r() * 260)),
  ),
  buildBaseRow("ctx-avg", "Context size (avg)", "percent", "avg", "context", (t) => {
    // grows within the session, resets after compaction at minute 150
    const seg = t < 150 ? t / 150 : (t - 150) / 180
    return Math.min(92, 38 + seg * 55)
  }),
  buildBaseRow("ctx-max", "Context size (max)", "percent", "max", "context", (t) => {
    const seg = t < 150 ? t / 150 : (t - 150) / 180
    return Math.min(98, 50 + seg * 50)
  }),
  buildBaseRow(
    "cost",
    "Estimated cost",
    "usd",
    "sum",
    "cost",
    (t, r) => Math.round(envelope(t) * (0.004 + r() * 0.003) * 10000) / 10000,
    (t, r) => {
      if (t >= 200 && t < 214) return "unavailable"
      return r() < 0.05 && envelope(t) > 0.3 ? "partial" : "measured"
    },
  ),
]

const GROUP_DEFS: Array<{ id: string; label: string }> = [
  { id: "time", label: "Activity" },
  { id: "tokens", label: "Tokens" },
  { id: "context", label: "Context window" },
  { id: "cost", label: "Cost" },
]

// ---------------------------------------------------------------------------
// Aggregation
// ---------------------------------------------------------------------------

function aggregateRow(base: BaseRowDef, resolution: Resolution): HeatRow {
  const periods = Math.ceil(TOTAL_MINUTES / resolution)
  const cells: HeatCell[] = []
  for (let p = 0; p < periods; p++) {
    const start = p * resolution
    const end = Math.min(start + resolution, TOTAL_MINUTES)
    const slice = base.minutes.slice(start, end)
    const available = slice.filter((m) => m.status !== "unavailable")
    const bucketMinutes = end - start

    if (available.length === 0) {
      cells.push({ value: null, status: "unavailable", evidenceCount: 0, coveredMinutes: 0, bucketMinutes })
      continue
    }

    let value: number
    if (base.agg === "sum") value = available.reduce((a, m) => a + m.value, 0)
    else if (base.agg === "max") value = Math.max(...available.map((m) => m.value))
    else value = available.reduce((a, m) => a + m.value, 0) / available.length

    if (base.unit === "usd") value = Math.round(value * 10000) / 10000

    const anyPartial = slice.some((m) => m.status === "partial")
    const anyMissing = available.length < slice.length
    cells.push({
      value,
      status: anyPartial || anyMissing ? "partial" : "measured",
      evidenceCount: available.reduce((a, m) => a + m.evidence.length, 0),
      coveredMinutes: available.length,
      bucketMinutes,
    })
  }
  return { id: base.id, label: base.label, unit: base.unit, agg: base.agg, group: base.group, cells }
}

const cache = new Map<Resolution, HeatGroup[]>()

export function getHeatGroups(resolution: Resolution): HeatGroup[] {
  const cached = cache.get(resolution)
  if (cached) return cached
  const rows = BASE_ROWS.map((b) => aggregateRow(b, resolution))
  const groups = GROUP_DEFS.map((g) => ({ ...g, rows: rows.filter((r) => r.group === g.id) }))
  cache.set(resolution, groups)
  return groups
}

export function periodCount(resolution: Resolution): number {
  return Math.ceil(TOTAL_MINUTES / resolution)
}

/** Raw evidence records backing one aggregated cell. */
export function getEvidence(rowId: string, resolution: Resolution, period: number): EvidenceRecord[] {
  const base = BASE_ROWS.find((b) => b.id === rowId)
  if (!base) return []
  const start = period * resolution
  const end = Math.min(start + resolution, TOTAL_MINUTES)
  return base.minutes.slice(start, end).flatMap((m) => m.evidence)
}

/** Which minutes inside the bucket are unavailable (for coverage display). */
export function getMissingWindows(rowId: string, resolution: Resolution, period: number): Array<[number, number]> {
  const base = BASE_ROWS.find((b) => b.id === rowId)
  if (!base) return []
  const start = period * resolution
  const end = Math.min(start + resolution, TOTAL_MINUTES)
  const windows: Array<[number, number]> = []
  let open: number | null = null
  for (let t = start; t < end; t++) {
    const missing = base.minutes[t].status === "unavailable"
    if (missing && open === null) open = t
    if (!missing && open !== null) {
      windows.push([open, t])
      open = null
    }
  }
  if (open !== null) windows.push([open, end])
  return windows
}

export interface RowStats {
  min: number
  max: number
  flat: boolean
}

export function rowStats(row: HeatRow): RowStats {
  const vals = row.cells.filter((c) => c.value !== null).map((c) => c.value as number)
  if (vals.length === 0) return { min: 0, max: 0, flat: true }
  const min = Math.min(...vals)
  const max = Math.max(...vals)
  const flat = max === min || (max !== 0 && (max - min) / Math.abs(max) < 0.02)
  return { min, max, flat }
}
