import { HeatmapBoard } from "@/components/heatmap/heatmap-board"

export default function Page() {
  return (
    <main className="mx-auto flex min-h-svh max-w-6xl flex-col gap-6 px-4 py-8 md:px-8">
      <header className="flex flex-wrap items-end justify-between gap-4 border-b border-border pb-5">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            Browser verification host
          </p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight text-balance">
            Session heatmap
          </h1>
        </div>
        <p className="font-mono text-xs text-muted-foreground">
          Aug 12, 2026 · 08:00–12:00 EDT · 4 hours of 1-min measurements
        </p>
      </header>

      <HeatmapBoard />
    </main>
  )
}
