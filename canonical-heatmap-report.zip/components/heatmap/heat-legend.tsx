export function HeatLegend() {
  return (
    <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
      <span className="flex items-center gap-1.5">
        Low
        <span
          aria-hidden="true"
          className="h-2.5 w-16 rounded-full"
          style={{
            background: "linear-gradient(to right, var(--heat-low), var(--heat-high))",
          }}
        />
        High <span className="text-muted-foreground/70">(per row)</span>
      </span>
      <span className="flex items-center gap-1.5">
        <span className="relative inline-block size-3 rounded-[2px]" style={{ backgroundColor: "var(--heat-flat)" }}>
          <span
            aria-hidden="true"
            className="absolute right-0 top-0 size-0 border-l-[5px] border-t-[5px] border-l-transparent"
            style={{ borderTopColor: "var(--flag)" }}
          />
        </span>
        Partial
      </span>
      <span className="flex items-center gap-1.5">
        <span
          aria-hidden="true"
          className="inline-block size-3 rounded-[2px]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(-45deg, transparent, transparent 2px, var(--grid-line) 2px, var(--grid-line) 3px)",
          }}
        />
        Unavailable
      </span>
    </div>
  )
}
