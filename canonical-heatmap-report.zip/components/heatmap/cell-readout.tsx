"use client"

import {
  formatValue,
  periodRangeLabel,
  rowStats,
  unitLabel,
  type HeatCell,
  type HeatRow,
  type Resolution,
} from "@/lib/heatmap-data"

export interface CellRef {
  row: HeatRow
  cell: HeatCell
  period: number
}

interface CellReadoutProps {
  active: CellRef | null
  resolution: Resolution
  isPinned: boolean
  onClear: () => void
}

export function CellReadout({ active, resolution, isPinned, onClear }: CellReadoutProps) {
  if (!active) {
    return (
      <div className="flex h-9 items-center rounded-md border border-dashed border-border px-3 text-xs text-muted-foreground">
        Hover a cell to inspect it. Click to pin and see its raw evidence below the grid.
      </div>
    )
  }

  const { row, cell, period } = active
  const stats = rowStats(row)
  const share =
    cell.value !== null && !stats.flat && stats.max > stats.min
      ? Math.round(((cell.value - stats.min) / (stats.max - stats.min)) * 100)
      : null

  return (
    <div className="flex h-9 items-center gap-x-4 overflow-x-auto rounded-md border border-border bg-card px-3 font-mono text-xs">
      <span className="shrink-0 text-muted-foreground">{periodRangeLabel(period, resolution)}</span>
      <span className="shrink-0 font-sans font-medium text-foreground">{row.label}</span>
      <span className="shrink-0 text-foreground">
        {cell.status === "unavailable" ? "unavailable" : formatValue(cell.value, row.unit)}
        <span className="ml-1 text-muted-foreground">{cell.status !== "unavailable" && unitLabel(row.unit)}</span>
      </span>
      {share !== null && <span className="shrink-0 text-muted-foreground">{share}% of row range</span>}
      {cell.status === "partial" && (
        <span
          className="shrink-0 rounded-sm px-1.5 py-0.5 text-[10px] font-medium"
          style={{
            backgroundColor: "color-mix(in oklch, var(--flag) 18%, transparent)",
            color: "var(--flag)",
          }}
        >
          partial · {cell.coveredMinutes}/{cell.bucketMinutes} min · {cell.evidenceCount} records
        </span>
      )}
      {cell.status === "measured" && (
        <span className="shrink-0 text-muted-foreground">{cell.evidenceCount} records</span>
      )}
      {isPinned && (
        <button
          type="button"
          onClick={onClear}
          className="ml-auto shrink-0 rounded-sm border border-border px-1.5 py-0.5 font-sans text-[10px] text-muted-foreground hover:text-foreground"
        >
          Unpin
        </button>
      )}
    </div>
  )
}
